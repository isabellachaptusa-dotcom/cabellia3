/* =========================================================
   CABELLIA — app.js
   Lógica compartida por TODAS las páginas: construye la
   navegación según el estado de autenticación (única fuente
   de verdad: auth.js) y maneja el menú móvil.
   ========================================================= */

const NAV_GUEST = [
  { href: 'index.html', label: 'Inicio', key: 'inicio' },
  { href: 'nosotros.html', label: 'Más sobre nosotros', key: 'nosotros' }
];

const NAV_GUEST_ACTIONS = [
  { href: 'login.html', label: 'Iniciar sesión', variant: 'btn-outline' },
  { href: 'registro.html', label: 'Registrarse', variant: 'btn-primary' }
];

const NAV_AUTH = [
  { href: 'index.html', label: 'Inicio', key: 'inicio' },
  { href: 'perfil.html', label: 'Perfil', key: 'perfil' },
  { href: 'resultados.html', label: 'Tus resultados', key: 'resultados' },
  { href: 'estilistas.html', label: 'Estilistas', key: 'estilistas' },
  { href: 'productos.html', label: 'Productos', key: 'productos' },
  { href: 'nosotros.html', label: 'Más sobre nosotros', key: 'nosotros' }
];

function initNavbar(activeKey) {
  const mount = document.getElementById('site-nav');
  if (!mount) return;

  const user = getCurrentUser();
  const links = user ? NAV_AUTH : NAV_GUEST;

  const linksHtml = links.map(link => {
    const isActive = link.key === activeKey;
    return `<a href="${link.href}" class="${isActive ? 'active' : ''}">${link.label}</a>`;
  }).join('');

  let actionsHtml = '';
  if (user) {
    const initials = user.name.trim().split(/\s+/).slice(0, 2).map(w => w[0].toUpperCase()).join('');
    actionsHtml = `
      <div class="nav-user">
        <span class="nav-avatar">${initials}</span>
        <span>${escapeHtml(user.name.split(' ')[0])}</span>
      </div>
      <button class="btn btn-ghost btn-sm" id="logout-btn" type="button">Cerrar sesión</button>
    `;
  } else {
    actionsHtml = NAV_GUEST_ACTIONS.map(a =>
      `<a class="btn ${a.variant} btn-sm" href="${a.href}">${a.label}</a>`
    ).join('');
  }

  mount.innerHTML = `
    <div class="nav-inner">
      <a href="index.html" class="brand">
        <span class="brand-mark">C</span> Cabellia
      </a>
      <button class="nav-burger" id="nav-burger" type="button" aria-label="Abrir menú">
        <span></span><span></span><span></span>
      </button>
      <div class="nav-links" id="nav-links">${linksHtml}</div>
      <div class="nav-actions">${actionsHtml}</div>
    </div>
  `;

  const burger = document.getElementById('nav-burger');
  const navLinks = document.getElementById('nav-links');
  if (burger && navLinks) {
    burger.addEventListener('click', () => navLinks.classList.toggle('open'));
  }

  const logoutBtn = document.getElementById('logout-btn');
  if (logoutBtn) {
    logoutBtn.addEventListener('click', () => {
      logoutUser();
      window.location.href = 'index.html';
    });
  }
}

function initFooter() {
  const mount = document.getElementById('site-footer');
  if (!mount) return;
  mount.innerHTML = `
    <div class="footer-inner">
      <span>© ${new Date().getFullYear()} Cabellia. Todos los derechos reservados.</span>
      <span>Tu cabello, nuestra prioridad.</span>
    </div>
  `;
}

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

/* Inicialización que corre en cada página vía data-active en <body> */
document.addEventListener('DOMContentLoaded', () => {
  const activeKey = document.body.getAttribute('data-active') || '';
  initNavbar(activeKey);
  initFooter();
});
