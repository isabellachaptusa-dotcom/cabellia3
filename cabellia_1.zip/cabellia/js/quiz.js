/* =========================================================
   CABELLIA — quiz.js
   Controla la página quiz.html: intro -> 4 preguntas -> guardar
   resultado -> redirigir a resultados.html
   ========================================================= */

(function initQuizPage() {
  const root = document.getElementById('quiz-root');
  if (!root) return; // no estamos en quiz.html

  const user = requireAuth();
  if (!user) return;

  const answers = { texture: null, condition: null, goal: null, heat: null };
  let currentStep = -1; // -1 = pantalla de intro

  function render() {
    if (currentStep === -1) return renderIntro();
    if (currentStep >= QUIZ_QUESTIONS.length) return finishQuiz();
    renderQuestion(QUIZ_QUESTIONS[currentStep]);
  }

  function renderIntro() {
    root.innerHTML = `
      <div class="quiz-card quiz-intro">
        <div class="quiz-intro-icon">🌿</div>
        <h1>Tu cabello, nuestra prioridad</h1>
        <p class="auth-sub">Este quiz te ayudará a conocer tu perfil capilar y a recibir consejos, estilistas y productos pensados para ti. Son solo 4 preguntas.</p>
        <div class="hero-cta" style="justify-content:center">
          <button class="btn btn-primary" id="quiz-start">Comenzar quiz</button>
          <a class="btn btn-ghost" href="perfil.html">Saltar por ahora</a>
        </div>
      </div>
    `;
    document.getElementById('quiz-start').addEventListener('click', () => {
      currentStep = 0;
      render();
    });
  }

  function renderQuestion(q) {
    const total = QUIZ_QUESTIONS.length;
    const progress = Math.round((currentStep / total) * 100);
    const options = Object.values(q.source);
    const selected = answers[q.id];

    root.innerHTML = `
      <div class="quiz-card">
        <div class="quiz-progress-track">
          <div class="quiz-progress-fill" style="width:${progress}%"></div>
        </div>
        <div class="quiz-step-label">Pregunta ${q.step} de ${total}</div>
        <h2 class="quiz-question">${q.question}</h2>
        <p class="auth-sub" style="margin-top:-14px">${q.hint}</p>
        <div class="quiz-options" id="quiz-options">
          ${options.map(opt => `
            <button type="button" class="quiz-option ${selected === opt.id ? 'selected' : ''}" data-id="${opt.id}">
              <span class="quiz-option-icon">${opt.icon || '•'}</span>
              <span class="quiz-option-text"><strong>${opt.label}</strong></span>
              <span class="quiz-option-check"></span>
            </button>
          `).join('')}
        </div>
        <div class="quiz-nav">
          <button class="btn btn-ghost" id="quiz-back" type="button" ${currentStep === 0 ? 'disabled' : ''}>← Atrás</button>
          <button class="btn btn-primary" id="quiz-next" type="button" ${selected ? '' : 'disabled'}>
            ${currentStep === total - 1 ? 'Ver mis resultados' : 'Siguiente →'}
          </button>
        </div>
      </div>
    `;

    root.querySelectorAll('.quiz-option').forEach(btn => {
      btn.addEventListener('click', () => {
        answers[q.id] = btn.getAttribute('data-id');
        renderQuestion(q);
      });
    });

    document.getElementById('quiz-back').addEventListener('click', () => {
      currentStep = Math.max(0, currentStep - 1);
      render();
    });

    document.getElementById('quiz-next').addEventListener('click', () => {
      if (!answers[q.id]) return;
      currentStep += 1;
      render();
    });
  }

  function finishQuiz() {
    const profileId = `${answers.texture}_${answers.condition}_${answers.goal}`;
    const profile = getProfileById(profileId);

    if (!profile) {
      // Salvaguarda: nunca debería pasar si las 4 preguntas se respondieron.
      root.innerHTML = `
        <div class="quiz-card center">
          <h2>Ocurrió un problema al calcular tu perfil</h2>
          <p class="auth-sub">Vuelve a intentar el quiz.</p>
          <button class="btn btn-primary" id="quiz-retry">Reintentar quiz</button>
        </div>
      `;
      document.getElementById('quiz-retry').addEventListener('click', () => {
        currentStep = 0;
        render();
      });
      return;
    }

    saveQuizResult(profileId, answers.heat);

    root.innerHTML = `
      <div class="quiz-card center">
        <div class="quiz-intro-icon">✨</div>
        <h1>¡Tu perfil está listo!</h1>
        <p class="auth-sub">${profile.profileName}</p>
        <button class="btn btn-primary" id="quiz-see-results">Ver mis resultados</button>
      </div>
    `;
    document.getElementById('quiz-see-results').addEventListener('click', () => {
      window.location.href = 'resultados.html';
    });
  }

  render();
})();
