/* =========================================================
   CABELLIA — data.js
   Fuente única de datos estáticos: texturas, estados, objetivos,
   los 64 perfiles capilares, el modificador de calor y los
   datos mock de estilistas y productos.
   ========================================================= */

/* ---------- 1. Texturas (pregunta 1) ---------- */
const TEXTURES = {
  straight: {
    id: 'straight',
    label: 'Liso',
    icon: '〰️',
    desc: 'tu cabello liso tiende a caer con naturalidad y a lucir brillo con facilidad',
    care: 'evita sobrecargarlo de productos pesados, que pueden dejarlo con aspecto grasoso rápidamente'
  },
  wavy: {
    id: 'wavy',
    label: 'Ondulado',
    icon: '🌊',
    desc: 'tu cabello ondulado combina cuerpo y movimiento, con una onda que se define mejor con la técnica correcta',
    care: 'trabaja el producto con las manos ahuecadas para reforzar la onda sin encresparla'
  },
  curly: {
    id: 'curly',
    label: 'Rizado',
    icon: '🌀',
    desc: 'tu cabello rizado forma espirales definidas que necesitan hidratación constante para mantener su forma',
    care: 'aplica los productos con el cabello húmedo y evita el cepillado en seco'
  },
  coily: {
    id: 'coily',
    label: 'Afro',
    icon: '🌿',
    desc: 'tu cabello afro tiene una textura densa y de patrón muy cerrado, con tendencia natural a la sequedad',
    care: 'sella la hidratación con un aceite o manteca después de cada aplicación de agua o crema'
  }
};

/* ---------- 2. Estado actual (pregunta 2) ---------- */
const CONDITIONS = {
  dry: {
    id: 'dry',
    label: 'Seco',
    icon: '🍂',
    desc: 'actualmente se siente seco y pide un aporte extra de agua y humectantes',
    care: 'incorpora una mascarilla hidratante semanal y reduce el uso de productos con alcohol'
  },
  normal: {
    id: 'normal',
    label: 'Normal',
    icon: '🍃',
    desc: 'se encuentra en un buen equilibrio, así que la prioridad es mantener ese balance',
    care: 'sostén una rutina simple: limpieza suave, acondicionador y protección ocasional'
  },
  oily: {
    id: 'oily',
    label: 'Graso',
    icon: '💧',
    desc: 'produce exceso de sebo en la raíz, lo que pide productos más ligeros y limpieza frecuente',
    care: 'usa champús purificantes en la raíz y reserva las cremas pesadas solo para las puntas'
  },
  damaged: {
    id: 'damaged',
    label: 'Dañado',
    icon: '⚡',
    desc: 'muestra señales de daño —puntas abiertas o pérdida de elasticidad— y necesita reparación activa',
    care: 'prioriza tratamientos con proteínas y aminoácidos, y reduce los procesos químicos por un tiempo'
  }
};

/* ---------- 3. Objetivo principal (pregunta 3) ---------- */
const GOALS = {
  hydration: {
    id: 'hydration',
    label: 'Hidratación',
    icon: '💧',
    tips: [
      'usa un acondicionador sin enjuague en las medias longitudes y puntas todos los días',
      'incluye una mascarilla hidratante a base de humectantes una vez por semana',
      'evita lavar el cabello con agua demasiado caliente, ya que reseca la fibra capilar'
    ]
  },
  definition: {
    id: 'definition',
    label: 'Definición',
    icon: '🌀',
    tips: [
      'aplica una crema o gel definidor sobre el cabello húmedo, mechón por mechón',
      'deja secar al aire o con difusor en lugar de frotar con la toalla',
      'refresca los rizos por las mañanas con un poco de agua y un toque de leave-in'
    ]
  },
  repair: {
    id: 'repair',
    label: 'Reparación',
    icon: '🩹',
    tips: [
      'incorpora un tratamiento reconstructor con proteínas cada dos semanas',
      'reduce la frecuencia de herramientas de calor y procesos químicos mientras el cabello se recupera',
      'corta las puntas abiertas para evitar que el daño avance por el tallo'
    ]
  },
  oil_control: {
    id: 'oil_control',
    label: 'Control de grasa',
    icon: '🍃',
    tips: [
      'lava la raíz con un champú purificante o con arcilla dos o tres veces por semana',
      'evita tocar demasiado el cuero cabelludo, ya que estimula la producción de sebo',
      'reserva el acondicionador solo para las puntas, sin aplicarlo en la raíz'
    ]
  }
};

/* ---------- 4. Modificador de calor (pregunta 4) ---------- */
const HEAT_MODIFIERS = {
  never: {
    id: 'never',
    label: 'Nunca o casi nunca',
    tip: 'como casi no usas herramientas de calor, tu cabello conserva mejor su hidratación natural: mantén esa costumbre.'
  },
  occasionally: {
    id: 'occasionally',
    label: 'Ocasionalmente',
    tip: 'cuando uses secador, plancha o tenaza, aplica antes un protector térmico para minimizar el impacto del calor.'
  },
  frequently: {
    id: 'frequently',
    label: 'Frecuentemente',
    tip: 'intenta espaciar el uso de herramientas de calor y aplica siempre protector térmico antes de usarlas: el uso frecuente acelera el daño.'
  },
  daily: {
    id: 'daily',
    label: 'Casi todos los días',
    tip: 'el uso diario de calor es la causa más probable de daño en tu cabello ahora mismo: reducirlo es tu prioridad número uno, y cuando lo uses, aplica siempre protector térmico.'
  }
};

/* ---------- 5. Preguntas del quiz ---------- */
const QUIZ_QUESTIONS = [
  {
    id: 'texture',
    step: 1,
    question: '¿Cuál es la textura de tu cabello?',
    hint: 'Elige la opción que más se parezca a tu cabello al natural.',
    source: TEXTURES
  },
  {
    id: 'condition',
    step: 2,
    question: '¿Cómo sientes tu cabello actualmente?',
    hint: 'Piensa en cómo se siente hoy, no en cómo te gustaría que fuera.',
    source: CONDITIONS
  },
  {
    id: 'goal',
    step: 3,
    question: '¿Cuál es tu principal objetivo?',
    hint: 'Elige el resultado que más te gustaría conseguir.',
    source: GOALS
  },
  {
    id: 'heat',
    step: 4,
    question: '¿Con qué frecuencia utilizas herramientas de calor?',
    hint: 'Secador, plancha o tenaza. Esto ajusta tus consejos finales.',
    source: HEAT_MODIFIERS
  }
];

/* ---------- 6. Generación de los 64 perfiles capilares ---------- */
/*
  texture (4) × condition (4) × goal (4) = 64 combinaciones.
  Cada perfil se compone dinámicamente a partir de los textos de
  TEXTURES, CONDITIONS y GOALS de arriba, evitando 64 bloques de
  texto duplicados. El resultado sigue siendo específico para cada
  combinación porque interpola las tres piezas de información.
*/
function buildProfile(textureId, conditionId, goalId) {
  const t = TEXTURES[textureId];
  const c = CONDITIONS[conditionId];
  const g = GOALS[goalId];
  const id = `${textureId}_${conditionId}_${goalId}`;
  const profileName = `${t.label} · ${c.label} · ${g.label}`;

  const hairInfo =
    `Tienes cabello ${t.label.toLowerCase()}: ${t.desc}. Hoy en día ${c.desc}. ` +
    `Tu prioridad declarada es ${g.label.toLowerCase()}, así que el resto de tu rutina debería girar en torno a eso.`;

  const baseTips = [
    `Cuidado de textura: ${t.care}.`,
    `Cuidado por estado: ${c.care}.`,
    ...g.tips
  ];

  return { id, texture: textureId, condition: conditionId, goal: goalId, profileName, hairInfo, baseTips };
}

const HAIR_PROFILES = (() => {
  const list = [];
  Object.keys(TEXTURES).forEach(textureId => {
    Object.keys(CONDITIONS).forEach(conditionId => {
      Object.keys(GOALS).forEach(goalId => {
        list.push(buildProfile(textureId, conditionId, goalId));
      });
    });
  });
  return list;
})();

function getProfileById(profileId) {
  return HAIR_PROFILES.find(p => p.id === profileId) || null;
}

/* Combina los consejos base del perfil con el consejo del modificador de calor */
function getFullTips(profileId, heatId) {
  const profile = getProfileById(profileId);
  if (!profile) return [];
  const heat = HEAT_MODIFIERS[heatId];
  const tips = [...profile.baseTips];
  if (heat) tips.push(`Sobre el uso de calor: ${heat.tip}`);
  return tips;
}

/* ---------- 7. Estilistas (mock) ---------- */
/* Preparado para sustituirse por una fuente real: cada estilista
   puede declarar `matchesGoals` para relacionarse con perfiles. */
const STYLISTS = [
  {
    id: 'st_1',
    name: 'María López',
    specialty: 'Especialista en cabello rizado',
    initials: 'ML',
    rating: 4.8,
    reviews: 120,
    bio: 'Más de 10 años definiendo rizos y enseñando rutinas de mantenimiento en casa.',
    matchesTextures: ['curly', 'coily']
  },
  {
    id: 'st_2',
    name: 'Carlos Ramírez',
    specialty: 'Especialista en cabello ondulado',
    initials: 'CR',
    rating: 4.7,
    reviews: 98,
    bio: 'Formado en cortes texturizados para realzar la onda natural sin perder movimiento.',
    matchesTextures: ['wavy']
  },
  {
    id: 'st_3',
    name: 'Ana Torres',
    specialty: 'Reparación y tratamientos capilares',
    initials: 'AT',
    rating: 4.9,
    reviews: 145,
    bio: 'Enfocada en recuperar cabello dañado con protocolos de proteína y densidad.',
    matchesConditions: ['damaged']
  },
  {
    id: 'st_4',
    name: 'Luis Fernández',
    specialty: 'Cortes y color para cabello liso',
    initials: 'LF',
    rating: 4.6,
    reviews: 76,
    bio: 'Especialista en brillo, color y cortes de precisión para cabello liso y fino.',
    matchesTextures: ['straight']
  },
  {
    id: 'st_5',
    name: 'Gabriela Ruiz',
    specialty: 'Cuidado de cabello afro y protección',
    initials: 'GR',
    rating: 4.9,
    reviews: 133,
    bio: 'Experta en hidratación profunda y peinados protectores para cabello afro.',
    matchesTextures: ['coily']
  },
  {
    id: 'st_6',
    name: 'Diego Moreno',
    specialty: 'Control de grasa y salud del cuero cabelludo',
    initials: 'DM',
    rating: 4.5,
    reviews: 61,
    bio: 'Especializado en tricología y rutinas para cueros cabelludos grasos o sensibles.',
    matchesConditions: ['oily']
  }
];

/* ---------- 8. Productos (mock) ---------- */
/* Preparado para sustituirse por una base de datos real. Cada
   producto puede declarar `profileGoals` para relacionarse con
   el objetivo (goal) de un perfil capilar. */
const PRODUCTS = [
  {
    id: 'pr_1',
    name: 'Curl Defining Cream',
    brand: 'Shea Moisture',
    price: 36.00,
    rating: 4.8,
    type: 'Crema',
    emoji: '🧴',
    profileGoals: ['definition']
  },
  {
    id: 'pr_2',
    name: 'Hydrating Shampoo',
    brand: 'Devines',
    price: 24.90,
    rating: 4.7,
    type: 'Champú',
    emoji: '🧼',
    profileGoals: ['hydration']
  },
  {
    id: 'pr_3',
    name: 'Leave-in Conditioner',
    brand: 'Cantu',
    price: 22.99,
    rating: 4.8,
    type: 'Leave-in',
    emoji: '💧',
    profileGoals: ['hydration', 'definition']
  },
  {
    id: 'pr_4',
    name: 'Protein Repair Mask',
    brand: 'Olaplex',
    price: 42.00,
    rating: 4.9,
    type: 'Mascarilla',
    emoji: '🩹',
    profileGoals: ['repair']
  },
  {
    id: 'pr_5',
    name: 'Clarifying Root Shampoo',
    brand: 'Nioxin',
    price: 19.50,
    rating: 4.4,
    type: 'Champú',
    emoji: '🍃',
    profileGoals: ['oil_control']
  },
  {
    id: 'pr_6',
    name: 'Heat Protectant Spray',
    brand: 'Tresemmé',
    price: 14.20,
    rating: 4.5,
    type: 'Protector térmico',
    emoji: '🛡️',
    profileGoals: ['repair', 'hydration', 'definition', 'oil_control']
  },
  {
    id: 'pr_7',
    name: 'Sealing Hair Butter',
    brand: 'Cantu',
    price: 18.00,
    rating: 4.7,
    type: 'Manteca',
    emoji: '🥥',
    profileGoals: ['hydration']
  },
  {
    id: 'pr_8',
    name: 'Lightweight Argan Oil',
    brand: 'Moroccanoil',
    price: 29.90,
    rating: 4.8,
    type: 'Aceite',
    emoji: '✨',
    profileGoals: ['definition', 'repair']
  }
];

function getRecommendedProducts(profileId, limit) {
  const profile = getProfileById(profileId);
  if (!profile) return PRODUCTS.slice(0, limit || PRODUCTS.length);
  const matches = PRODUCTS.filter(p => p.profileGoals.includes(profile.goal));
  const rest = PRODUCTS.filter(p => !p.profileGoals.includes(profile.goal));
  const ordered = [...matches, ...rest];
  return limit ? ordered.slice(0, limit) : ordered;
}

function getRecommendedStylists(profileId, limit) {
  const profile = getProfileById(profileId);
  if (!profile) return STYLISTS.slice(0, limit || STYLISTS.length);
  const score = st => {
    let s = 0;
    if (st.matchesTextures && st.matchesTextures.includes(profile.texture)) s += 2;
    if (st.matchesConditions && st.matchesConditions.includes(profile.condition)) s += 1;
    return s;
  };
  const ordered = [...STYLISTS].sort((a, b) => score(b) - score(a));
  return limit ? ordered.slice(0, limit) : ordered;
}
