/* =========================================================
   CABELLIA — results.js
   Lógica de: perfil.html, resultados.html, estilistas.html y
   productos.html. También controla el sub-nav independiente
   "Tus resultados | Estilistas | Productos".
   ========================================================= */

const SUBNAV_ITEMS = [
  { href: 'resultados.html', label: 'Resultados', key: 'resultados' },
  { href: 'estilistas.html', label: 'Estilistas', key: 'estilistas' },
  { href: 'productos.html', label: 'Productos', key: 'productos' }
];

/** Renderiza el sub-nav marcando como activo SOLO la sección actual. */
function renderSubnav(mountId, activeKey) {
  const mount = document.getElementById(mountId);
  if (!mount) return;
  mount.innerHTML = SUBNAV_ITEMS.map(item =>
    `<a href="${item.href}" class="${item.key === activeKey ? 'active' : ''}">${item.label}</a>`
  ).join('');
}

/* ---------- Perfil ---------- */
function renderProfilePage() {
  const mount = document.getElementById('profile-root');
  if (!mount) return;

  const user = requireAuth();
  if (!user) return;

  const initials = user.name.trim().split(/\s+/).slice(0, 2).map(w => w[0].toUpperCase()).join('');

  if (!user.quizCompleted || !user.quizResult) {
    mount.innerHTML = `
      <div class="profile-head">
        <span class="profile-avatar">${initials}</span>
        <div>
          <h1 class="profile-name">${escapeHtml(user.name)}</h1>
          <div class="profile-email">${escapeHtml(user.email)}</div>
        </div>
      </div>
      <div class="card empty-state">
        <div class="emoji">🌱</div>
        <h3>Aún no tienes un perfil capilar.</h3>
        <p>Responde 4 preguntas rápidas y descubre tu perfil, tus consejos y tus recomendaciones personalizadas.</p>
        <a href="quiz.html" class="btn btn-primary">Realizar quiz</a>
      </div>
    `;
    return;
  }

  const profile = getProfileById(user.quizResult.profileId);
  mount.innerHTML = `
    <div class="profile-grid">
      <div>
        <div class="profile-head">
          <span class="profile-avatar">${initials}</span>
          <div>
            <h1 class="profile-name">${escapeHtml(user.name)}</h1>
            <div class="profile-email">${escapeHtml(user.email)}</div>
          </div>
        </div>
        <div class="card">
          <h3>Mi perfil capilar</h3>
          <div class="tag-row">
            <span class="tag">${TEXTURES[profile.texture].label}</span>
            <span class="tag">${CONDITIONS[profile.condition].label}</span>
            <span class="tag">${GOALS[profile.goal].label}</span>
          </div>
          <p>${profile.hairInfo}</p>
          <a href="resultados.html" class="btn btn-outline btn-sm">Ver detalles →</a>
        </div>
      </div>
      <div class="card">
        <h3>Último quiz</h3>
        <p style="color:var(--ink-faint); font-size:.85rem">
          Completado el ${new Date(user.quizResult.completedAt).toLocaleDateString('es-ES', { day: 'numeric', month: 'long', year: 'numeric' })}
        </p>
        <a href="quiz.html" class="btn btn-primary btn-block">Rehacer quiz</a>
      </div>
    </div>
  `;
}

/* ---------- Resultados ---------- */
function renderResultsPage() {
  const mount = document.getElementById('results-root');
  if (!mount) return;

  renderSubnav('results-subnav', 'resultados');

  const user = requireAuth();
  if (!user) return;

  if (!user.quizCompleted || !user.quizResult) {
    mount.innerHTML = `
      <div class="card empty-state">
        <div class="emoji">🌱</div>
        <h3>Todavía no tienes resultados.</h3>
        <p>Haz el quiz capilar para desbloquear tu perfil, tus consejos y tus recomendaciones.</p>
        <a href="quiz.html" class="btn btn-primary">Realizar quiz</a>
      </div>
    `;
    return;
  }

  const profile = getProfileById(user.quizResult.profileId);
  const tips = getFullTips(profile.id, user.quizResult.heat);

  mount.innerHTML = `
    <div class="result-hero">
      <div class="swatch"></div>
      <div>
        <div class="tag-row" style="margin:0 0 6px">
          <span class="tag">${TEXTURES[profile.texture].label}</span>
          <span class="tag">${CONDITIONS[profile.condition].label}</span>
          <span class="tag">${GOALS[profile.goal].label}</span>
        </div>
        <h2 style="margin:0">${profile.profileName}</h2>
      </div>
    </div>
    <div class="result-block">
      <div class="card">
        <h3>Información de tu cabello</h3>
        <p>${profile.hairInfo}</p>
      </div>
      <div class="card">
        <h3>Consejos para ti</h3>
        <ul class="tips-list">
          ${tips.map(t => `<li>${t}</li>`).join('')}
        </ul>
      </div>
    </div>
  `;
}

/* ---------- Estilistas ---------- */
function renderStylistsPage() {
  const mount = document.getElementById('stylists-root');
  if (!mount) return;

  renderSubnav('results-subnav', 'estilistas');

  const user = requireAuth();
  if (!user) return;

  const profileId = user.quizResult ? user.quizResult.profileId : null;
  const stylists = getRecommendedStylists(profileId);

  mount.innerHTML = `
    <div class="grid grid-3">
      ${stylists.map(st => `
        <div class="card people-card">
          <span class="people-avatar">${st.initials}</span>
          <h3>${st.name}</h3>
          <p style="color:var(--ink-soft); font-size:.9rem">${st.specialty}</p>
          <p style="font-size:.88rem">${st.bio}</p>
          <div class="rating">★ ${st.rating.toFixed(1)} <span style="color:var(--ink-faint); font-weight:400">(${st.reviews} reseñas)</span></div>
          <a href="#" class="btn btn-outline btn-sm" style="margin-top:14px" onclick="return false;">Ver perfil</a>
        </div>
      `).join('')}
    </div>
  `;
}

/* ---------- Productos ---------- */
function renderProductsPage() {
  const mount = document.getElementById('products-root');
  if (!mount) return;

  renderSubnav('results-subnav', 'productos');

  const user = requireAuth();
  if (!user) return;

  const profileId = user.quizResult ? user.quizResult.profileId : null;
  let allProducts = getRecommendedProducts(profileId);

  function draw(list) {
    mount.innerHTML = `
      <div class="grid grid-4">
        ${list.map(p => `
          <div class="card product-card">
            <div class="product-thumb">${p.emoji}</div>
            <h3 style="font-size:1rem">${p.name}</h3>
            <p style="color:var(--ink-faint); font-size:.85rem; margin-bottom:2px">${p.brand}</p>
            <div class="product-price">$${p.price.toFixed(2)}</div>
            <div class="rating">★ ${p.rating.toFixed(1)}</div>
          </div>
        `).join('') || `<p class="auth-sub">No se encontraron productos con ese filtro.</p>`}
      </div>
    `;
  }

  const search = document.getElementById('product-search');
  const typeFilter = document.getElementById('product-type');

  const types = ['Todos', ...Array.from(new Set(PRODUCTS.map(p => p.type)))];
  if (typeFilter) {
    typeFilter.innerHTML = types.map(t => `<option value="${t}">${t}</option>`).join('');
  }

  function applyFilters() {
    const q = (search && search.value || '').trim().toLowerCase();
    const type = (typeFilter && typeFilter.value) || 'Todos';
    let list = allProducts;
    if (type !== 'Todos') list = list.filter(p => p.type === type);
    if (q) list = list.filter(p => p.name.toLowerCase().includes(q) || p.brand.toLowerCase().includes(q));
    draw(list);
  }

  if (search) search.addEventListener('input', applyFilters);
  if (typeFilter) typeFilter.addEventListener('change', applyFilters);

  draw(allProducts);
}

/* ---------- Init automático según qué root exista en la página ---------- */
document.addEventListener('DOMContentLoaded', () => {
  renderProfilePage();
  renderResultsPage();
  renderStylistsPage();
  renderProductsPage();
});
