/* =========================================================
   CABELLIA — auth.js
   Simulación de autenticación de frontend (NO es un sistema
   de autenticación seguro para producción). Única fuente de
   verdad del estado de sesión: localStorage.

   Claves usadas en localStorage:
     cabellia_users        -> array de usuarios registrados
     cabellia_currentUser  -> id del usuario con sesión activa
   ========================================================= */

const STORAGE_KEYS = {
  users: 'cabellia_users',
  currentUser: 'cabellia_currentUser'
};

/* ---------- Utilidades de almacenamiento ---------- */
function readUsers() {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.users);
    return raw ? JSON.parse(raw) : [];
  } catch (e) {
    console.error('Cabellia: no se pudo leer usuarios', e);
    return [];
  }
}

function writeUsers(users) {
  localStorage.setItem(STORAGE_KEYS.users, JSON.stringify(users));
}

function setCurrentUserId(id) {
  if (id) localStorage.setItem(STORAGE_KEYS.currentUser, id);
  else localStorage.removeItem(STORAGE_KEYS.currentUser);
}

function getCurrentUserId() {
  return localStorage.getItem(STORAGE_KEYS.currentUser);
}

/* ---------- API pública de autenticación ---------- */

/** Devuelve el usuario con sesión activa (objeto completo) o null. */
function getCurrentUser() {
  const id = getCurrentUserId();
  if (!id) return null;
  const users = readUsers();
  return users.find(u => u.id === id) || null;
}

function isAuthenticated() {
  return !!getCurrentUser();
}

function emailExists(email) {
  const normalized = email.trim().toLowerCase();
  return readUsers().some(u => u.email.toLowerCase() === normalized);
}

/**
 * Registra un nuevo usuario, inicia sesión automáticamente y
 * devuelve { ok:true, user } o { ok:false, error }.
 */
function registerUser({ name, email, password }) {
  name = (name || '').trim();
  email = (email || '').trim();

  if (!name || !email || !password) {
    return { ok: false, error: 'Completa nombre, correo y contraseña.' };
  }
  if (!/^\S+@\S+\.\S+$/.test(email)) {
    return { ok: false, error: 'Ingresa un correo electrónico válido.' };
  }
  if (password.length < 6) {
    return { ok: false, error: 'La contraseña debe tener al menos 6 caracteres.' };
  }
  if (emailExists(email)) {
    return { ok: false, error: 'Ya existe una cuenta registrada con ese correo.' };
  }

  const user = {
    id: 'u_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 7),
    name,
    email,
    password, // NOTA: solo para fines de demostración de frontend.
    quizCompleted: false,
    quizResult: null // { profileId, heat, completedAt }
  };

  const users = readUsers();
  users.push(user);
  writeUsers(users);
  setCurrentUserId(user.id);

  return { ok: true, user };
}

/**
 * Inicia sesión validando correo y contraseña.
 * Devuelve { ok:true, user } o { ok:false, error }.
 */
function loginUser({ email, password }) {
  email = (email || '').trim();
  if (!email || !password) {
    return { ok: false, error: 'Ingresa tu correo y contraseña.' };
  }
  const users = readUsers();
  const user = users.find(u => u.email.toLowerCase() === email.toLowerCase());

  if (!user || user.password !== password) {
    return { ok: false, error: 'Correo o contraseña incorrectos.' };
  }

  setCurrentUserId(user.id);
  return { ok: true, user };
}

/** Cierra la sesión activa sin borrar los datos del usuario. */
function logoutUser() {
  setCurrentUserId(null);
}

/** Actualiza el resultado del quiz del usuario con sesión activa. */
function saveQuizResult(profileId, heatId) {
  const currentId = getCurrentUserId();
  if (!currentId) return false;

  const users = readUsers();
  const idx = users.findIndex(u => u.id === currentId);
  if (idx === -1) return false;

  users[idx].quizCompleted = true;
  users[idx].quizResult = {
    profileId,
    heat: heatId,
    completedAt: new Date().toISOString()
  };
  writeUsers(users);
  return true;
}

/**
 * Protege una página privada: si no hay sesión, redirige a login.html
 * y detiene la ejecución del resto del script de la página.
 * Devuelve el usuario actual si la sesión es válida.
 */
function requireAuth() {
  const user = getCurrentUser();
  if (!user) {
    window.location.replace('login.html');
    return null;
  }
  return user;
}

/**
 * Igual que requireAuth, pero además exige que el usuario ya
 * haya completado el quiz. Si no lo ha hecho, redirige a perfil.html
 * (donde se muestra el estado vacío con la opción de hacer el quiz).
 */
function requireQuizResult() {
  const user = requireAuth();
  if (!user) return null;
  if (!user.quizCompleted || !user.quizResult) {
    window.location.replace('perfil.html');
    return null;
  }
  return user;
}
